package it.cattaneo.gestioneorari;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Passa(View view){

        Intent openPage1 = new Intent(MainActivity.this,ClassiActivity.class);
        startActivity(openPage1);

    }

    public void Passa2(View view){

        Intent openPage2 = new Intent(MainActivity.this,AuleActivity.class);
        startActivity(openPage2);

    }

    public void Passa3(View view){

        Intent openPage3 = new Intent(MainActivity.this,ProfessoriActivity.class);
        startActivity(openPage3);

    }
}