/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.catta.login;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author alex
 */
@WebService(serviceName = "ProviderLogin")
public class ProviderLogin {
    final static int TABELLA_OPERAZIONI = 1;
    String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    String DB_URL = "jdbc:mysql://localhost/iis_jean_monnet";

    String USER = "root";
    String PASS = "";
    Connection conn ;
    Statement stmt ;
    @WebMethod(operationName = "Login")
    public String Login(@WebParam(name = "ID") String ID, @WebParam(name = "Psw") String Psw) throws SQLException {
        //TODO write your implementation code here:
         System.out.println("Creating statement...");
        stmt = (Statement) conn.createStatement();
         ArrayList utenti = null;   
        String sql = "SELECT * FROM utente";
        ResultSet rs=null;
            if (sql != null) {
                rs = stmt.executeQuery(sql);

                // iterate through the java resultset
                while (rs.next()) {
                    //Retrieve by column name
                    String user = rs.getString("utente");
                    String psw = rs.getString("password");

                    utenti.add(nome);
                    // debug: print the results
                    System.out.format("%s, %s\n", id, nome);
                }

                rs.close();
        }
        String s= "Dati corretti";
        String r= "Dati errati";
        String v= "admin";
        
        if(ID.equals(v) && Psw.equals(v))
            return s;
        else
            return r;
        
    }

    @WebMethod(operationName = "Registrazione")
    public String Registrazione(@WebParam(name = "id") String id, @WebParam(name = "psw") String psw) {
        //TODO write your implementation code here:
        String s="Sei stato registrato";
        String v="admin";
        String r="Username gia presente nel db";
        
            if(id.equals(v))
                return r;
            else
                return s;
        
    }

    @WebMethod(operationName = "Modifica")
    public String Modifica(@WebParam(name = "username") String username, @WebParam(name = "nuovaPsw") String nuovaPsw, @WebParam(name = "confermaPsw") String confermaPsw) {
        //TODO write your implementation code here:
        String s;
        if(nuovaPsw.equals(confermaPsw))
            s="La password di "+username+" è stata modificata";
        else
            s="La password di "+username+" non è stata modificata";
        
        return s;
    }
    
    @WebMethod(operationName = "Connessione")
    public String Connessione(@WebParam(name = "Conn") String Conn) throws SQLException {
        
        //TODO write your implementation code here:
        String s ="si";
        String n ="no";
        if(Conn.equals(s)){
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");
            return "Sei stato connesso";
        }
        else if(Conn.equals(n))
            return "Non sei stato connesso";
        else
            return "Hai scritto una cazzata, riscrivi si o no"; 
    }
    
    @WebMethod(operationName = "Disconnessione")
    public String Disconnessione(@WebParam(name = "Conn") String Conn) {
        //TODO write your implementation code here:
        String s ="si";
        String n ="no";
        if(Conn.equals(s))
            return "Disconnessione effettuata";
        else if(Conn.equals(n))
            return "Non sei stato disconnesso";
        else
            return "Riscrivi si o no";
    }
    private ArrayList gelFromDatabase(int table) {
        ArrayList<String> arraylist = new ArrayList<String>();

        

        Connection conn = null;
        
        Statement stmt = null;

        try {
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

           

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = (Statement) conn.createStatement();
            
            String sql = "";

            switch (table) {
                case TABELLA_OPERAZIONI:
                    sql = "SELECT * FROM operazioni";
                    break;
                default:
                    break;
            }
            ResultSet rs=null;
            if (sql != null) {
                rs = stmt.executeQuery(sql);

                // iterate through the java resultset
                while (rs.next()) {
                    //Retrieve by column name
                    int id = rs.getInt("id");
                    String nome = rs.getString("nome");

                    arraylist.add(nome);
                    // debug: print the results
                    System.out.format("%s, %s\n", id, nome);
                }

                rs.close();
            }
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }

        return arraylist;
    }
}
