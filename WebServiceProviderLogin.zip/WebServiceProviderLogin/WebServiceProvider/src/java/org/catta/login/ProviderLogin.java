/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.catta.login;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author alex
 */
@WebService(serviceName = "ProviderLogin")
public class ProviderLogin {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "Login")
    public String Login(@WebParam(name = "ID") String ID, @WebParam(name = "Psw") String Psw) {
        //TODO write your implementation code here:
        String s= "Dati corretti";
        String r= "Dati errati";
        String v= "admin";
        
        if(ID.equals(v) && Psw.equals(v))
            return s;
        else
            return r;
        
    }
}
