/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.giodabg.application;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
    import javax.jws.WebMethod;
    import javax.jws.WebParam;
    import java.sql.*;
/**
 *
 * @author alex
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {
    
    Connection conn;
    
    
    



    /**
     * Web service operation
     */
    @WebMethod(operationName = "Upload")
    public void Upload(@WebParam(name = "nomeFile") String nomeFile) {
        
        
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/file";
            conn = DriverManager.getConnection(url, "root", "");
        try
        {
          Statement st = conn.createStatement();
          st.executeUpdate("INSERT INTO tabella(nome) " +
                           "VALUES ('"+nomeFile+"')");
        }
        catch (SQLException ex)
        {
          System.err.println(ex.getMessage());
        }
        
             conn.close();
        } catch (ClassNotFoundException ex) {
            System.err.println(ex.getMessage());
        } catch (IllegalAccessException ex) {
            System.err.println(ex.getMessage());
        } catch (InstantiationException ex) {
            System.err.println(ex.getMessage());
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        
    }
    
    private Boolean doSelectTest(String query) {

        
        Boolean r = false;
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
             if(rs.first())   
                r=true;
            
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return r;
    }
	

}
