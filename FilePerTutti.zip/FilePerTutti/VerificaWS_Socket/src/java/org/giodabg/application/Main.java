
package org.giodabg.application;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
/**
 *
 * @author cattaneo_alex
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
        public static void main(String[] args) {
            		
	try {
            SocketServer s = new SocketServer();
            
            s.attendi();
            
            while(true){
            s.comunica();
            
	    String str = s.getDati();
            
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("C:\\Upload\\"+str.substring(0,str.indexOf("-")), false)));
            
            out.println(str.substring(str.indexOf("-")+1));
            
            
            out.flush();
            out.close(); 
            // apre il file in scrittura
	System.out.println("Inserito");        
	}          
	} catch (IOException e) {
	         System.out.println(e);
	        } 
	
        }
}

    

