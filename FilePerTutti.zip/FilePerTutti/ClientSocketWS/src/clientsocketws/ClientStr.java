/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientsocketws;

/**
 *
 * @author molteni_matteo
 */
import java.io.*;
import java.net.*;

public class ClientStr {
String nomeServer;
int portaServer;
Socket miosocket; 
String stringaUtente;
String stringaRicevutaDalServer; 
DataOutputStream outVersoServer; 
BufferedReader inDalServer;
public ClientStr(){
	nomeServer="192.168.1.10";
        portaServer=6789;
}
public void comunica(String dati){
	try		// leggo una riga
	{
		
		// la spedisco al server
		System.out.println("invio la stringa al server");
		outVersoServer.writeBytes(dati);
		// leggo la risposta del server
		stringaRicevutaDalServer=inDalServer.readLine();
                miosocket.close();
		
		
	}
	catch (Exception e)
	{
		System.out.println(e.getMessage());
		System.out.println("Errore durante la comunicazione con il server");
		System.exit(1);
	}
}
public Socket connetti(){
	System.out.println("client partito in esecuzione");
	try
	{
		// creo un socket
		miosocket = new Socket(nomeServer,portaServer);
		// miosocket = new Socket(InetAddress.GetLocalHost(),6789);
		// associo due oggetti al socket per effettuare la scrittura e la lettura
		outVersoServer = new DataOutputStream(miosocket.getOutputStream());
		inDalServer	= new BufferedReader(new InputStreamReader(miosocket.getInputStream()));
	}
	catch (UnknownHostException e) {
		System.err.println("Host  sconosciuto");}
	catch (Exception e)
	{
		System.out.println(e.getMessage());
		System.out.println("Errore durante la connessione!");	
		System.exit(1);
		}
		return miosocket;
	}
}