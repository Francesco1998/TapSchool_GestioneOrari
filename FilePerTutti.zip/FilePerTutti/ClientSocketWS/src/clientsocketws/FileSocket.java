/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientsocketws;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.*;
/**
 *
 * @author molteni_matteo
 */
public class FileSocket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Inserisci il nome del file che vuoi mandare al server");
        Scanner input = new Scanner(System.in);
        String s1 = input.nextLine();
        String var = s1+".txt";
        upload(var);
        try {
            FileReader f1 = null;
            try {
                f1=new FileReader(var);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            BufferedReader b;
            b=new BufferedReader(f1);
            ClientStr client=new ClientStr();
            client.connetti();
            int i ;
            String s="";
            while ((i = b.read()) != -1) {
                char ch = (char) i;
                s+=ch;
                
            }
            
            client.comunica(var+"-"+s);
            try {
                b.close();
            } catch (IOException ex) {
                Logger.getLogger(FileSocket.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
            Logger.getLogger(FileSocket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    private static void upload(java.lang.String nomeFile) {
        org.giodabg.application.NewWebService_Service service = new org.giodabg.application.NewWebService_Service();
        org.giodabg.application.NewWebService port = service.getNewWebServicePort();
        port.upload(nomeFile);
    }

   

    

    
    
}
