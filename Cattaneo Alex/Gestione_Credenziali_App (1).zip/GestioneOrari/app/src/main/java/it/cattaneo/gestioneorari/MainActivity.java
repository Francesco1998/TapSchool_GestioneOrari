package it.cattaneo.gestioneorari;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Passa(View view){

        Intent openPage1 = new Intent(MainActivity.this,LoginActivity.class);
        startActivity(openPage1);

    }

    public void Passa2(View view){

        Intent openPage1 = new Intent(MainActivity.this,RegistrazioneActivity.class);
        startActivity(openPage1);

    }
}